package factory;

import view.CandyLabel;

public class CandyLabelTimeFactory extends CandyLabelFactory{

	public CandyLabelTimeFactory() {
		// TODO Auto-generated constructor stub
	}
	
	public CandyLabel createLabelScore(){
		return new CandyLabel("");}
	
}
